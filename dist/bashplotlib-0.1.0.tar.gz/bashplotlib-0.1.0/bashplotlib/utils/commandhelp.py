
hist = {
    "usage": "this is a histogram"
}

scatter = {
    "usage": "this is a scatterplot"
}

